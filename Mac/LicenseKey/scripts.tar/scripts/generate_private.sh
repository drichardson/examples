#!/bin/bash
openssl genrsa -out private.pem 1024
